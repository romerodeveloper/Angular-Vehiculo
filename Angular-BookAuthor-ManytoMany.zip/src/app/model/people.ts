export class People {
    id : number
    name : string
    surname : string
    age : string
    country : string
    email : string
}