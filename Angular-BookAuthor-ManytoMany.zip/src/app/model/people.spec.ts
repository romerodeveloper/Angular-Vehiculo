import { People } from './people';

describe('Book', () => {
  it('should create an instance', () => {
    expect(new People()).toBeTruthy();
  });
});